# backend/app/routes/auth.py

from flask import Blueprint, request, jsonify
from flask_jwt_extended import create_access_token, create_refresh_token, jwt_required, get_jwt_identity, get_jwt
from app import db, bcrypt
from app.models.user import User
from app.models.activity import ActivityLog
from app.models.session import UserSession
from app.models.subscription import UserSubscription, SubscriptionPlan
from app.services.email_service import EmailService
from app.services.auth_service import AuthService
from app.services.password_reset_service import PasswordResetService
from app.utils.validators import validate_email, validate_password, validate_username
from app.models.resume import ResumeEnhancement
from datetime import datetime, timedelta
import re
import uuid # --- FIX: Import uuid for session token generation

auth_bp = Blueprint('auth', __name__)

password_reset_service = PasswordResetService()

@auth_bp.route('/register', methods=['POST'])
def register():
    """Register a new user"""
    try:
        data = request.get_json()
        
        username = data.get('username', '').strip()
        email = data.get('email', '').strip().lower()
        password = data.get('password', '')
        first_name = data.get('first_name', '').strip()
        last_name = data.get('last_name', '').strip()
        
        if not username or not email or not password:
            return jsonify({'message': 'Username, email, and password are required'}), 400
        
        if not validate_username(username):
            return jsonify({'message': 'Username must be 3-50 characters long and contain only letters, numbers, and underscores'}), 400
        
        if not validate_email(email):
            return jsonify({'message': 'Invalid email address'}), 400
        
        is_valid_password, password_error = validate_password(password)
        if not is_valid_password:
            return jsonify({'message': password_error}), 400
        
        if User.query.filter_by(username=username).first():
            return jsonify({'message': 'Username already exists'}), 409
        
        if User.query.filter_by(email=email).first():
            return jsonify({'message': 'Email already registered'}), 409
        
        password_hash = bcrypt.generate_password_hash(password).decode('utf-8')
        
        new_user = User(
            username=username,
            email=email,
            password_hash=password_hash,
            first_name=first_name,
            last_name=last_name,
            is_active=True,
            is_verified=False
        )
        
        db.session.add(new_user)
        db.session.commit()

        try:
            email_service = EmailService()
            email_service.send_welcome_email(to_email=new_user.email, user_name=new_user.first_name or new_user.username)
        except Exception as e:
            print(f"Failed to send welcome email to {new_user.email}: {e}")
        
        AuthService.log_activity(
            new_user.user_id, 
            'user_registered', 
            f'User {username} registered', 
            request.remote_addr,
            request.user_agent.string
        )
        
        access_token = create_access_token(identity=str(new_user.user_id))
        refresh_token = create_refresh_token(identity=str(new_user.user_id))
        
        AuthService.assign_free_subscription(new_user.user_id)
        
        return jsonify({
            'message': 'Registration successful',
            'user': new_user.to_dict(),
            'access_token': access_token,
            'refresh_token': refresh_token
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'message': 'Registration failed', 'error': str(e)}), 500

@auth_bp.route('/login', methods=['POST'])
def login():
    """Login with username/email and password"""
    try:
        data = request.get_json()
        login_identifier = data.get('login', '').strip()
        password = data.get('password', '')
        
        if not login_identifier or not password:
            return jsonify({'message': 'Login credentials are required'}), 400
        
        user = User.query.filter(
            (User.username == login_identifier) | (User.email == login_identifier.lower())
        ).first()
        
        if not user or not user.password_hash or not bcrypt.check_password_hash(user.password_hash, password):
            return jsonify({'message': 'Invalid credentials'}), 401
        
        if not user.is_active:
            return jsonify({'message': 'Account is deactivated'}), 403
        
        user.last_login = datetime.utcnow()
        
        # --- FIX START: Correct Session and Token Handling ---
        session_token = str(uuid.uuid4())
        
        new_session = UserSession(
            user_id=user.user_id,
            session_token=session_token,
            ip_address=request.remote_addr,
            user_agent=request.user_agent.string,
            expires_at=datetime.utcnow() + timedelta(hours=24)
        )
        db.session.add(new_session)

        AuthService.log_activity(
            user.user_id, 
            'user_login', 
            f'User {user.username} logged in', 
            request.remote_addr,
            request.user_agent.string
        )
        
        db.session.commit()
        
        # Embed the database session token into the JWT
        access_token = create_access_token(
            identity=str(user.user_id), 
            additional_claims={'session_token': session_token}
        )
        refresh_token = create_refresh_token(identity=str(user.user_id))
        # --- FIX END ---

        return jsonify({
            'message': 'Login successful',
            'user': user.to_dict(),
            'access_token': access_token,
            'refresh_token': refresh_token
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'message': 'Login failed', 'error': str(e)}), 500

@auth_bp.route('/logout', methods=['POST'])
@jwt_required()
def logout():
    """Logout user and invalidate session"""
    try:
        current_user_id = get_jwt_identity()
        claims = get_jwt()
        session_token = claims.get('session_token')

        # --- FIX START: Invalidate the session on logout using session_token from JWT ---
        if session_token:
            session_to_invalidate = UserSession.query.filter_by(session_token=session_token).first()
            if session_to_invalidate and session_to_invalidate.user_id == int(current_user_id):
                session_to_invalidate.is_active = False
                session_to_invalidate.expires_at = datetime.utcnow()
                db.session.commit()
        # --- FIX END ---

        AuthService.log_activity(
            current_user_id, 
            'user_logout', 
            'User logged out', 
            request.remote_addr,
            request.user_agent.string
        )
        
        return jsonify({'message': 'Logout successful'}), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'message': 'Logout failed', 'error': str(e)}), 500

@auth_bp.route('/refresh', methods=['POST'])
@jwt_required(refresh=True)
def refresh_token():
    try:
        current_user_id = get_jwt_identity()
        user = User.query.get(current_user_id)
        if not user or not user.is_active:
            return jsonify({'message': 'User not found or inactive'}), 401
        new_access_token = create_access_token(identity=str(current_user_id))
        return jsonify({'access_token': new_access_token}), 200
    except Exception as e:
        return jsonify({'message': 'Token refresh failed', 'error': str(e)}), 500

@auth_bp.route('/me', methods=['GET'])
@jwt_required()
def get_current_user():
    try:
        current_user_id = get_jwt_identity()
        user = User.query.get(current_user_id)
        if not user:
            return jsonify({'message': 'User not found'}), 404
        return jsonify({'user': user.to_dict()}), 200
    except Exception as e:
        return jsonify({'message': 'Failed to fetch user profile', 'error': str(e)}), 500

@auth_bp.route('/forgot-password', methods=['POST'])
def forgot_password():
    try:
        data = request.get_json()
        email = data.get('email', '').strip().lower()
        if not email or not validate_email(email):
            return jsonify({'message': 'Valid email address is required'}), 400
        
        success, message = password_reset_service.initiate_password_reset(
            email=email,
            ip_address=request.remote_addr
        )
        return jsonify({'message': message, 'success': success}), 200
    except Exception as e:
        return jsonify({'message': 'Failed to process password reset request', 'error': str(e)}), 500

@auth_bp.route('/verify-reset-token', methods=['POST'])
def verify_reset_token():
    try:
        data = request.get_json()
        email = data.get('email', '').strip().lower()
        token = data.get('token', '').strip()
        if not email or not token or not validate_email(email):
            return jsonify({'message': 'Email and verification code are required'}), 400
        
        is_valid, message, user = password_reset_service.verify_reset_token(email, token)
        if is_valid:
            return jsonify({'message': message, 'valid': True}), 200
        else:
            return jsonify({'message': message, 'valid': False}), 400
            
    except Exception as e:
        return jsonify({'message': 'Failed to verify reset token', 'error': str(e)}), 500

@auth_bp.route('/reset-password', methods=['POST'])
def reset_password():
    try:
        data = request.get_json()
        email = data.get('email', '').strip().lower()
        token = data.get('token', '').strip()
        new_password = data.get('new_password', '')
        confirm_password = data.get('confirm_password', '')
        
        if not all([email, token, new_password, confirm_password]):
            return jsonify({'message': 'All fields are required'}), 400
        
        if new_password != confirm_password:
            return jsonify({'message': 'Passwords do not match'}), 400
        
        is_valid_password, password_error = validate_password(new_password)
        if not is_valid_password:
            return jsonify({'message': password_error}), 400
        
        success, message = password_reset_service.reset_password(
            email=email,
            token=token,
            new_password=new_password,
            ip_address=request.remote_addr
        )
        
        if success:
            return jsonify({'message': message, 'success': True}), 200
        else:
            return jsonify({'message': message, 'success': False}), 400
            
    except Exception as e:
        return jsonify({'message': 'Failed to reset password', 'error': str(e)}), 500

@auth_bp.route('/change-password', methods=['POST'])
@jwt_required()
def change_password():
    try:
        current_user_id = get_jwt_identity()
        user = User.query.get(current_user_id)
        if not user:
            return jsonify({'message': 'User not found'}), 404
        
        data = request.get_json()
        current_password = data.get('current_password', '')
        new_password = data.get('new_password', '')
        confirm_password = data.get('confirm_password', '')
        
        if not all([current_password, new_password, confirm_password]):
            return jsonify({'message': 'All fields are required'}), 400
        
        if not bcrypt.check_password_hash(user.password_hash, current_password):
            return jsonify({'message': 'Current password is incorrect'}), 401
        
        if new_password != confirm_password:
            return jsonify({'message': 'New passwords do not match'}), 400
            
        is_valid_password, password_error = validate_password(new_password)
        if not is_valid_password:
            return jsonify({'message': password_error}), 400
        
        if bcrypt.check_password_hash(user.password_hash, new_password):
            return jsonify({'message': 'New password must be different from current password'}), 400
        
        user.password_hash = bcrypt.generate_password_hash(new_password).decode('utf-8')
        db.session.commit()
        
        email_service = password_reset_service.email_service
        email_service.send_password_change_confirmation(to_email=user.email, user_name=user.first_name)
        
        AuthService.log_activity(
            user.user_id,
            'password_changed',
            'Password changed by authenticated user',
            request.remote_addr
        )
        
        return jsonify({'message': 'Password changed successfully', 'success': True}), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'message': 'Failed to change password', 'error': str(e)}), 500
    
@auth_bp.route('/profile', methods=['PUT', 'PATCH'])
@jwt_required()
def update_profile():
    try:
        current_user_id = get_jwt_identity()
        user = User.query.get(current_user_id)
        if not user:
            return jsonify({'message': 'User not found'}), 404
        
        data = request.get_json()
        allowed_fields = ['first_name', 'last_name', 'phone_number', 'profession', 'location', 'bio']
        updated_fields = []
        for field in allowed_fields:
            if field in data:
                value = data[field]
                if value is not None:
                    value = str(value).strip()
                setattr(user, field, value if value else None)
                updated_fields.append(field)
        
        user.updated_at = datetime.utcnow()
        db.session.commit()
        
        AuthService.log_activity(
            current_user_id,
            'profile_updated',
            f'Profile updated: {", ".join(updated_fields)}',
            request.remote_addr
        )
        
        return jsonify({'message': 'Profile updated successfully', 'user': user.to_dict()}), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'message': 'Failed to update profile', 'error': str(e)}), 500
    
@auth_bp.route('/status', methods=['GET'])
@jwt_required()
def get_user_status():
    try:
        current_user_id = get_jwt_identity()
        user_subscription = UserSubscription.query.filter_by(user_id=current_user_id).first()
        
        if not user_subscription:
            return jsonify({'message': 'No active subscription found for user'}), 404
            
        plan = SubscriptionPlan.query.get(user_subscription.plan_id)
        if not plan:
            return jsonify({'message': 'Subscription plan not found'}), 404

        POLICY_START_DATE = datetime(2025, 8, 23)
        enhancement_count = ResumeEnhancement.query.filter(
            ResumeEnhancement.user_id == current_user_id,
            ResumeEnhancement.created_at >= POLICY_START_DATE
        ).count()
        
        remaining = "unlimited"
        if plan.resume_limit is not None:
            remaining = plan.resume_limit - enhancement_count
            if remaining < 0:
                remaining = 0

        return jsonify({
            'message': 'User status retrieved successfully',
            'status': {
                'plan_name': plan.plan_name,
                'resume_limit': plan.resume_limit,
                'enhancement_count': enhancement_count,
                'remaining_enhancements': remaining
            }
        }), 200
        
    except Exception as e:
        return jsonify({'message': 'Failed to retrieve user status', 'error': str(e)}), 500
    
@auth_bp.route('/stats', methods=['GET'])
@jwt_required()
def get_user_stats():
    try:
        current_user_id = get_jwt_identity()
        user_subscription = UserSubscription.query.filter_by(user_id=current_user_id).first()

        if not user_subscription:
            return jsonify({'message': 'No active subscription found for user'}), 404
            
        enhancement_count = ActivityLog.query.filter(
            ActivityLog.user_id == current_user_id, 
            ActivityLog.action == 'resume_enhanced',
            ActivityLog.created_at >= user_subscription.start_date
        ).count()
        
        return jsonify({
            'message': 'Stats retrieved successfully',
            'stats': {
                'enhancement_count': enhancement_count
            }
        }), 200
        
    except Exception as e:
        return jsonify({'message': 'Failed to retrieve user stats', 'error': str(e)}), 500

@auth_bp.route('/cleanup-expired-tokens', methods=['POST'])
def cleanup_expired_tokens():
    try:
        cleaned_count = password_reset_service.cleanup_expired_tokens()
        return jsonify({'message': f'Cleaned up {cleaned_count} expired tokens', 'count': cleaned_count}), 200
    except Exception as e:
        return jsonify({'message': 'Failed to cleanup expired tokens', 'error': str(e)}), 500

